rootProject.name = "timesheet-manager"
