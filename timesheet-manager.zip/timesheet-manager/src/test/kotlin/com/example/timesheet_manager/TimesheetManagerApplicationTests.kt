package com.example.timesheet_manager

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class TimesheetManagerApplicationTests {

	@Test
	fun contextLoads() {
	}

}
